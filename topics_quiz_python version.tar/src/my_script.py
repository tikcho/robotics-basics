#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

vel = Twist()

def callback(msgs):
    ranges = msgs.ranges
    f = ranges[360]  # front
    l = ranges[719]  # left
    r = ranges[0]    # right

    if (f > 1.0) :
        vel.linear.x = 0.2
        vel.angular.z = 0
    else : 
        vel.angular.z = 0.5

    if (r < 1.0) : vel.angular.z = -0.5
    elif (l < 1.0) : vel.angular.z = 0.5
    

rospy.init_node('topics_quiz_node')

pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
sub = rospy.Subscriber('/kobuki/laser/scan', LaserScan, callback)
# rospy.spin()    
rate = rospy.Rate(2)

while not rospy.is_shutdown():
    pub.publish(vel)
    rate.sleep()